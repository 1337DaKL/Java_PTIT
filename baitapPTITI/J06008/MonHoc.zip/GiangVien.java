/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1.Java_PTIT.baitapPTITI.J06008;

/**
 *
 * @author daklp
 */
public class GiangVien {
    private String tenGiangVien , maGiangVien ;

    public GiangVien(String maGiangVien, String tenGiangVien) {
        this.tenGiangVien = tenGiangVien;
        this.maGiangVien = maGiangVien;
    }

    public String getTenGiangVien() {
        return tenGiangVien;
    }

    public String getMaGiangVien() {
        return maGiangVien;
    }
    
}
