/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1.Java_PTIT.baitapPTITI.J07011;

/**
 *
 * @author daklp
 */
import java.util.*;
import java.io.*;
public class Main{
    public static void main(String[] args) throws FileNotFoundException , IOException , ClassNotFoundException{
        File file = new File("src/javaapplication1/Java_PTIT/baitapPTITI/J07011/VANBAN.in");
        Scanner sc = new Scanner(file);
        int maxo = Integer.MIN_VALUE;
        TreeMap<String , Integer> map = new TreeMap<>();
        while(sc.hasNextLine())
        {
            String s = sc.nextLine();
            String ok = "";
            for(int i = 0 ; i < s.length() ; i++)
            {
                char x = s.charAt(i);
                if(x == ',' || x == '.' || x == '?' || x == '!' || x == ':' || x == ';' || x == '(' || x == ')' || x == '-' || x == '/')
                {
                    ok += " ";
                }
                else
                {
                    ok += s.charAt(i);
                }
            }
            String[] arr = ok.trim().toLowerCase().split("\\s+");
            for(int i = 0 ; i < arr.length ; i++)
            {
                if(map.containsKey(arr[i]))
                {
                    map.put(arr[i], map.get(arr[i]) + 1);
                }
                else
                {
                    map.put(arr[i], 1);
                }
            }
        }
        Set<Map.Entry<String , Integer>> entrys = map.entrySet();
        for(Map.Entry<String , Integer> x : entrys)
        {
            maxo = Math.max(maxo, x.getValue());
        }
        while(maxo > 0)
        {
            for(Map.Entry<String , Integer> x : entrys)
            {
                if(x.getValue() == maxo)
                {
                    System.out.println(x.getKey() + " " + x.getValue());
                }
            }
            maxo--;
        }
    }
}
