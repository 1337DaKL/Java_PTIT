/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thucHanhLanThu2.quanLiBaiTapNhom;

/**
 *
 * @author luong
 */
public class BaiTap {
    public String maBaiTap , tenBaiTapString;

    public BaiTap(String maBaiTap, String tenBaiTapString) {
        this.maBaiTap = maBaiTap;
        this.tenBaiTapString = tenBaiTapString;
    }

    public String getMaBaiTap() {
        return maBaiTap;
    }

    public String getTenBaiTapString() {
        return tenBaiTapString;
    }
    
}
